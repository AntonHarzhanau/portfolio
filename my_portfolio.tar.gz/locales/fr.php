<?php
$TRAD = array(
    "Projects" => "Projets",
    "Skills" => "Competence",
    "Welcom" => "Bienvenue sur mon site Web personnel! Mon nom est ",
    "Text" => "Ce site est mon espace numérique où je partage mes projets.",
    "Btn_download" => "Télécharger CV",
    "h2_Projects_title" => "Projets",
    "Btn_show_more" => "Montre plus",
    "Form_label" => "Formulaire de contact",
    "Name_placeholder" => "Votre prénom",
    "Email_placeholder" => "Votre email",
    "Message_placehoder" => "Votre message",
    "Btn_send_form" => "Envoyer",
    "error_name" => "Le nom est vide.",
    "error_mail" => "L'adresse email saisie ne semble pas être valide.",
    "error_message" => "Veuillez saisir un message avant de l'envoyer."
);