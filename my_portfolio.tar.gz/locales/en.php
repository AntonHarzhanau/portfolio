<?php
$TRAD = array(
    "Projects" => "Projects",
    "Skills" => "Skills",
    "Welcom" => "Welcome to my personal website! My name is",
    "Text" => "This site is my digital space where I share my  projects.",
    "Btn_download" => "Download CV",
    "h2_Projects_title" => "Projects",
    "Btn_show_more" => "Show more",
    "Form_label" => "Contact form",
    "Name_placeholder" => "Your name",
    "Email_placeholder" => "Your email",
    "Message_placehoder" => "Your message",
    "Btn_send_form" => "Send",
    "error_name" => "Name is empty.",
    "error_mail" => "The email address entered does not appear to be valid.",
    "error_message" => "Please enter a message before sending."
);